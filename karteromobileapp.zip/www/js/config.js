/*Kartero App Configuration*/
var krms_driver_config ={		
	'ApiUrl':"http://192.168.0.35/kartero/api",					
	'DialogDefaultTitle':"Kartero",	
	'PushProjectID':"1006370283875",	
	'APIHasKey':"AIzaSyCCqKj53JxccxKBFeJJy7XdZHVzxgc2RJU"
};